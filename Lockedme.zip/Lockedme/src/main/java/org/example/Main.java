package org.example;

import Functioanlity.Menu;

public class Main {
        public static final String path = "C:\\Users\\amitya2\\Downloads\\Lockedme";

        public static void main(String[] args) {
            Menu menu = new Menu();
            menu.introScreen();
            menu.mainMenu();
        }

}